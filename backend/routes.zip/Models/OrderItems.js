import { DataTypes } from "sequelize";
import sequelize from "../dbconnection.js";
import Customer from "./Customers.js";

const OrderItem = sequelize.define(
  "OrderItem",
  {
    size: {
      type: DataTypes.STRING,
    },

    qnty: {
      type: DataTypes.INTEGER,
      validate: {
        min: 1,
      },
    },
    fileName: {
      type: DataTypes.STRING,
    },
    price: {
      type: DataTypes.DECIMAL(10, 2),
      validate: {
        min: 0,
      },
    },

    money: {
      type: DataTypes.DECIMAL(10, 2),
      validate: {
        min: 0,
      }},
    receipt: {
      type: DataTypes.DECIMAL(10, 2),
      validate: {
        min: 0,
      },
    },
  },
  {
    timestamps: true,
  }
);

export default OrderItem;